/* =========================================================
   Beyond Borders — Vanilla JS
   ========================================================= */

(function () {
  'use strict';

  /* ---------- Mobile nav toggle ---------- */
  var toggle = document.getElementById('navToggle');
  var navMobile = document.getElementById('navMobile');
  if (toggle && navMobile) {
    toggle.addEventListener('click', function () {
      var open = navMobile.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    navMobile.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        navMobile.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* ---------- Gallery data ---------- */
  var wonders = [
    { title: 'Misty Mountain',     region: 'Patagonia, AR',   image: 'assets/misty-mountain.jpg',     tag: 'Peaks' },
    { title: 'Hidden Beach',       region: 'Marieta, MX',     image: 'assets/hidden-beach.jpg',       tag: 'Shores' },
    { title: 'Desert Oasis',       region: 'Siwa, EG',        image: 'assets/desert-oasis.jpg',       tag: 'Dunes' },
    { title: 'Nordic Forest',      region: 'Lapland, FI',     image: 'assets/nordic-forest.jpg',      tag: 'Wild' },
    { title: 'Cobblestone Street', region: 'Tuscany, IT',     image: 'assets/cobblestone-street.jpg', tag: 'Heritage' },
    { title: 'Alpine Lake',        region: 'Patagonia, CL',   image: 'assets/alpine-lake.jpg',        tag: 'Stillness' },
    { title: 'Temple Ruins',       region: 'Siem Reap, KH',   image: 'assets/temple-ruins.jpg',       tag: 'Ancient' },
    { title: 'Glacier Cave',       region: 'Vatnajökull, IS', image: 'assets/ice-cave.jpg',           tag: 'Arctic' }
  ];

  var INITIAL_COUNT = 4;
  var grid = document.getElementById('galleryGrid');
  var loadBtn = document.getElementById('loadMoreBtn');

  function renderCards(list) {
    if (!grid) return;
    grid.innerHTML = list.map(function (w) {
      return ''
        + '<article class="card">'
        +   '<img src="' + w.image + '" alt="' + w.title + ' — ' + w.region + '" loading="lazy" />'
        +   '<span class="tag">' + w.tag + '</span>'
        +   '<a href="#packages" class="go" aria-label="Explore ' + w.title + '">↗</a>'
        +   '<div class="info">'
        +     '<p class="region">' + w.region + '</p>'
        +     '<h3>' + w.title + '</h3>'
        +   '</div>'
        + '</article>';
    }).join('');
  }

  renderCards(wonders.slice(0, INITIAL_COUNT));

  if (loadBtn) {
    loadBtn.addEventListener('click', function () {
      renderCards(wonders);
      loadBtn.style.display = 'none';
    });
  }

  /* ---------- Testimonials ---------- */
  var reviews = [
    { name: 'Amelia R.', place: 'Faroe Islands, 2025',  body: 'I have travelled my whole life. Beyond Borders is the first company that designed a trip that felt like it was written for me.' },
    { name: 'Kenji T.',  place: 'Patagonia, 2024',      body: 'Every detail was already considered. I just had to show up and pay attention to the landscape.' },
    { name: 'Sara M.',   place: 'Atlas Mountains, 2025',body: 'The local guide became a friend by day three. That doesn\'t happen by accident — it\'s how they design things.' },
    { name: 'Lucas P.',  place: 'Lapland, 2024',        body: 'Quiet luxury done right. Nothing felt staged, nothing felt rushed. I\'m already booking the next one.' },
    { name: 'Hana K.',   place: 'Tuscany, 2025',        body: 'A small group, an extraordinary chef, and a villa I never want to leave. Effortless from start to finish.' }
  ];

  var scroller = document.getElementById('reviewsScroller');
  if (scroller) {
    scroller.innerHTML = reviews.map(function (r) {
      return ''
        + '<article class="review">'
        +   '<span class="quote-mark">"</span>'
        +   '<p class="body">' + r.body + '</p>'
        +   '<div class="who">'
        +     '<span class="avatar">' + r.name.charAt(0) + '</span>'
        +     '<div>'
        +       '<div class="name">' + r.name + '</div>'
        +       '<div class="place">' + r.place + '</div>'
        +     '</div>'
        +   '</div>'
        + '</article>';
    }).join('');
  }

  /* ---------- Subscribe form ---------- */
  var form = document.getElementById('subscribeForm');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var input = form.querySelector('input[type="email"]');
      var value = input.value.trim();
      if (!value || !/^\S+@\S+\.\S+$/.test(value)) {
        input.focus();
        input.style.outline = '2px solid #c0392b';
        return;
      }
      input.style.outline = 'none';
      var btn = form.querySelector('button');
      btn.textContent = '✓ Subscribed';
      btn.disabled = true;
      input.value = '';
    });
  }

  /* ---------- Year ---------- */
  var y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();
})();
